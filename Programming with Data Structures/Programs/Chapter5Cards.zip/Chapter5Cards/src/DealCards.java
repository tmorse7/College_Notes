
import java.util.Arrays;

//********************************************************************
//  DealCards.java       Java Foundations
//  Solution to Programming Project 5.13
//  Played with by Lee to check for dups
//********************************************************************
public class DealCards {
    //-----------------------------------------------------------------
    //  Creates and prints a random set of playing cards (allows
    //  duplicates).
    //-----------------------------------------------------------------

    public static void main(String[] args) {
        final int NUM_CARDS = 5;
        Card[] cards = new Card[NUM_CARDS];
        Card card;

        for (int count = 0; count < NUM_CARDS; count++) {
            card = new Card();
            System.out.println("Dealer gives me a " + card);
            cards[count] = card;
            
            // Check for duplicates in the array already
            
            if (count == 0) {
                continue;
            }
            if (count == 1 && card.equals(cards[0])) {
                killit(cards);
            }
            if (count == 2
                    && (card.equals(cards[0]) || card.equals(cards[1]))) {
                killit(cards);
            }
            if (count == 3
                    && (card.equals(cards[0]) || card.equals(cards[1])
                    || card.equals(cards[2]))) {
                killit(cards);
            }
            if (count == 4
                    && (card.equals(cards[0]) || card.equals(cards[1])
                    || card.equals(cards[2]) || card.equals(cards[3]))) {
                killit(cards);
            }

        }
        //System.out.println(Arrays.toString(cards));
        System.out.println("I got a good hand. Let's play poker.");
        for (int x = 0; x < cards.length; x++) {
            System.out.println(cards[x]);
        }
    }

    private static void killit(Card[] cards) {
        System.out.println("This came from a crooked deck. Draw your gun!");
        System.out.println(Arrays.toString(cards));
        System.exit(99999);
    }
}
