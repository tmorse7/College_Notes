
/**
 * Sorting demonstrates sorting and searching on an array
 * of objects.
 *
 * Start to Programming Project 18.3 (count comparisons)
 *
 * @author Java Foundations/ and Lee, converted to nanoseconds!
 * @version 4.0
 */
public class Sorting {

    /**
     * Sorts the specified array of integers using the selection sort algorithm.
     *
     * @param data the array to be sorted
     */
    public static <T extends Comparable<T>>
            void selectionSort(T[] data) {
        int min, comparisons = 0;
        long startTime, stopTime;

        //startTime = System.currentTimeMillis();
        startTime = System.nanoTime();
        //Fix me with sort code
        for (int index = 0; index < data.length - 1; index++) {
            comparisons++;
        }

        //stopTime = System.currentTimeMillis();
        stopTime = System.nanoTime();
        System.out.println("Selection Sort");
        System.out.println("Running time (ns): " + (stopTime - startTime));
        System.out.println("Comparisons: " + comparisons);
        System.out.println("==================================================");
    }

    /**
     * Swaps to elements in an array. Used by various sorting algorithms.
     *
     * @param data the array in which the elements are swapped
     * @param index1 the index of the first element to be swapped
     * @param index2 the index of the second element to be swapped
     */
    private static <T extends Comparable<T>>
            void swap(T[] data, int index1, int index2) {
        T temp = data[index1];
        data[index1] = data[index2];
        data[index2] = temp;
    }

    /**
     * Sorts the specified array of objects using an insertion sort algorithm.
     *
     * @param data the array to be sorted
     */
    public static <T extends Comparable<T>>
            void insertionSort(T[] data) {
        int comparisons = 0;
        long startTime, stopTime;

        startTime = System.nanoTime();
        //Fix me with sort code
        for (int index = 1; index < data.length; index++) {
            comparisons++;

        }

        stopTime = System.nanoTime();
        System.out.println("Insertion Sort");
        System.out.println("Running time (ns): " + (stopTime - startTime));
        System.out.println("Comparisons: " + comparisons);
        System.out.println("==================================================");
    }

    /**
     * Sorts the specified array of objects using a bubble sort algorithm.
     *
     * @param data the array to be sorted
     */
    public static <T extends Comparable<T>>
            void bubbleSort(T[] data) {
        int position, scan, comparisons = 0;
        long startTime, stopTime;

        startTime = System.nanoTime();
        //Fix me with sort code
        for (int index = 0; index < data.length - 1; index++) {

            comparisons++;

        }

        stopTime = System.nanoTime();
        System.out.println("Bubble Sort");
        System.out.println("Running time (ns): " + (stopTime - startTime));
        System.out.println("Comparisons: " + comparisons);
        System.out.println("==================================================");
    }

    /**
     * Sorts the specified array of objects using the quick sort algorithm.
     *
     * @param data the array to be sorted
     */
    public static <T extends Comparable<T>>
            void quickSort(T[] data) {
        long startTime, stopTime;
        int[] comparisons = new int[1]; // array is used to preserve count
        comparisons[0] = 0;
        startTime = System.nanoTime();
        //Fix me with sort code
        

        stopTime = System.nanoTime();
        System.out.println("Quick Sort");
        System.out.println("Running time (ns): " + (stopTime - startTime));
        System.out.println("Comparisons: " + comparisons[0]);
        System.out.println("==================================================");
    }

    /**
     * Recursively sorts a range of objects in the specified array using the
     * quick sort algorithm.
     *
     * @param data the array to be sorted
     * @param min the minimum index in the range to be sorted
     * @param max the maximum index in the range to be sorted
     */
    private static <T extends Comparable<T>>
            void quickSort(T[] data, int min, int max, int[] sortCounter) {
        if (min < max) {
            //Fix me with sort code
        }
    }

    /**
     * Used by the quick sort algorithm to find the partition.
     *
     * @param data the array to be sorted
     * @param min the minimum index in the range to be sorted
     * @param max the maximum index in the range to be sorted
     */
    private static <T extends Comparable<T>>
            int partition(T[] data, int min, int max, int[] sortCounter) {
        //Fix me with sort code
        return 0;
    }

    /**
     * Sorts the specified array of objects using the merge sort algorithm.
     *
     * @param data the array to be sorted
     */
    public static <T extends Comparable<T>>
            void mergeSort(T[] data) {
        long startTime, stopTime;
        int[] comparisons = new int[1];  // array is used to preserve count
        comparisons[0] = 0;
        startTime = System.nanoTime();

        //Fix me with sort code

        stopTime = System.nanoTime();
        System.out.println("Merge Sort");
        System.out.println("Running time (ns): " + (stopTime - startTime));
        System.out.println("Comparisons: " + comparisons[0]);
        System.out.println("==================================================");
    }

    /**
     * Recursively sorts a range of objects in the specified array using the
     * merge sort algorithm.
     *
     * @param data the array to be sorted
     * @param min the index of the first element
     * @param max the index of the last element
     */
    private static <T extends Comparable<T>>
            void mergeSort(T[] data, int min, int max, int[] sortCounter) {
        if (min < max) {
            int mid = (min + max) / 2;
            mergeSort(data, min, mid, sortCounter);
            mergeSort(data, mid + 1, max, sortCounter);
            merge(data, min, mid, max, sortCounter);
        }
    }

    /**
     * Merges two sorted subarrays of the specified array.
     *
     * @param data the array to be sorted
     * @param first the beginning index of the first subarray
     * @param mid the ending index fo the first subarray
     * @param last the ending index of the second subarray
     */
    @SuppressWarnings("unchecked")
    private static <T extends Comparable<T>>
            void merge(T[] data, int first, int mid, int last, int[] sortCounter) {
        T[] temp = (T[]) (new Comparable[data.length]);

        int first1 = first, last1 = mid;  // endpoints of first subarray
        int first2 = mid + 1, last2 = last;  // endpoints of second subarray
        int index = first1;  // next index open in temp array

        //  Copy smaller item from each subarray into temp until one
        //  of the subarrays is exhausted
        while (first1 <= last1 && first2 <= last2) {
            // there are 2 comparisons in the while statement and one in the if statement
            sortCounter[0] += 3;
            if (data[first1].compareTo(data[first2]) < 0) {
                temp[index] = data[first1];
                first1++;
            } else {
                temp[index] = data[first2];
                first2++;
            }
            index++;
        }

        //  Copy remaining elements from first subarray, if any
        while (first1 <= last1) {
            sortCounter[0]++;
            temp[index] = data[first1];
            first1++;
            index++;
        }

        //  Copy remaining elements from second subarray, if any
        while (first2 <= last2) {
            sortCounter[0]++;
            temp[index] = data[first2];
            first2++;
            index++;
        }

        //  Copy merged data into original array
        for (index = first; index <= last; index++) {
            sortCounter[0]++;
            data[index] = temp[index];
        }
    }

}
