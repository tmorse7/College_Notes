package tmhomework4pt1;

/**
 * @date Apr 2, 2017
 * @author Tristan Morse
 */
class RAM {

    private String ramBrand;
    private String ramType;
    private Boolean RGBLEDs;
    private Integer speed;
    private Integer memory;

    public RAM(String ramBrand, String ramType) {
        this.ramBrand = ramBrand;
        this.ramType = ramType;
    }

    RAM() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String getRamBrand() {
        return ramBrand;
    }

    public void setRamBrand(String ramBrand) {
        this.ramBrand = ramBrand;
    }

    public String getRamType() {
        return ramType;
    }

    public void setRamType(String ramType) {
        this.ramType = ramType;
    }

    public Boolean getRGBLEDs() {
        return RGBLEDs;
    }

    public void setRGBLEDs(Boolean RGBLEDs) {
        this.RGBLEDs = RGBLEDs;
    }

    public Integer getSpeed() {
        return speed;
    }

    public void setSpeed(Integer speed) {
        this.speed = speed;
    }
    
    public void setMemory(Integer memory) {
        this.memory = memory;
    }
    
    public Integer getMemory() {
        return memory;
    }

    @Override
    public String toString() {
        return "*RAM* " + "RAM Brand: " + ramBrand + ", RAM Type: " + ramType + ", RGB Lighting: " + RGBLEDs + ", Speed: " + speed + ", Memory: " + memory + " GB" + "\n";
    }
    
}
