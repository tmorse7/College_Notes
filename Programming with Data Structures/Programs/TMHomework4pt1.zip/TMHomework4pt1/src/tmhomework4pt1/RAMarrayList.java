package tmhomework4pt1;

import java.util.Comparator;
import static java.util.Comparator.comparing;
import static java.util.Comparator.naturalOrder;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import static java.util.Comparator.comparing;

/**
 * @date Apr 2, 2017
 * @author Tristan Morse
 */
public class RAMarrayList {

    public static void main(String[] args) {
        
        List<RAM> list = new ArrayList<>();
        
        RAM r1 = new RAM("G.Skill TridentZ", "DDR4");
        RAM r2 = new RAM("Corsair Vengence LPX", "DDR4");
        RAM r3 = new RAM("Corsair Vengence RGB", "DDR4");
        
        r1.setRGBLEDs(Boolean.TRUE);
        r2.setRGBLEDs(Boolean.FALSE);
        r3.setRGBLEDs(Boolean.TRUE);
        
        r1.setSpeed(3200);
        r2.setSpeed(2666);
        r3.setSpeed(3000);
        
        r1.setMemory(8);
        r2.setMemory(8);
        r3.setMemory(8);

        list.add(r1);
        list.add(r2);
        list.add(r3);
        
        ListIterator<RAM> i = list.listIterator();
        
        while (i.hasNext()) {
            RAM tempram = i.next();
            if (tempram.getRGBLEDs() == Boolean.FALSE) {
                System.out.println(tempram + "doesn't include RGB LED lighting! Removing from the list." + "\n");
                list.remove(tempram);
            }
        }
        
        Comparator<RAM> comparator = comparing(RAM::getRamType, naturalOrder());

        list.sort(comparator);

        while (!list.isEmpty()) {
            RAM temp = list.remove(0); // keep removing at zero ? 
            System.out.println("Removed remaining item: " + temp);
        }
        
    }

}
