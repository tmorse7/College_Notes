/**
 * @date Mar 6, 2017
 * @author Tristan Morse
 */
public class TMHomework3ch12 {
    
    public static void main(String[] args) {
        String str = "hey";
        System.out.println();
    }

}
