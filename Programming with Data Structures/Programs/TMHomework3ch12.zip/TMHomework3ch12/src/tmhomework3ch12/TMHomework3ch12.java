package tmhomework3ch12;
import java.util.Scanner;
import java.util.Stack;

/**
 * @date Feb 26, 2017
 * @author Tristan Morse
 */
public class TMHomework3ch12 {
    
    public static void main(String[] args) {
        
        Stack<String> stack = new Stack<>();
        
        String sentence = "", word;
        try {
                Scanner in = new Scanner(System.in);
                System.out.println("Enter a sentence: ");
                sentence = in.nextLine();

                System.out.println("Reversed:");
                Scanner sentenceScanner = new Scanner(sentence);

                while (sentenceScanner.hasNext())
                {
                        word = sentenceScanner.next();

                        for (int i = 0; i < word.length(); i++)
                                stack.push(word.charAt(i) + "");

                        while (!stack.isEmpty())
                                System.out.print(stack.pop());

                        System.out.print("");
                }
                System.out.println();
        }
        catch (Exception IOException)
        {
            System.out.println("Input exception");
        }
        
    }

}
