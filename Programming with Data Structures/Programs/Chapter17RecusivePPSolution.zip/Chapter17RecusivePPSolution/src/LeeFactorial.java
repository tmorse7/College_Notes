
/**
 *
 * @author leejohnson
 */
public class LeeFactorial {

    public static void main(String[] args) {
        long startTime, stopTime, duration;
        startTime = System.nanoTime();
        System.out.println(factrec(10));
        stopTime = System.nanoTime();
        duration = stopTime - startTime;
        System.out.println("Recusive Duration(ns)= " + duration);

        startTime = System.nanoTime();
        System.out.println(factiter(10));
        stopTime = System.nanoTime();
        duration = stopTime - startTime;
        System.out.println("Iteration Duration(ns)= " + duration);
    }

    public static long factrec(long n) {
        if (n <= 1) {
            return 1;
        } else {
            return n * factrec(n - 1);
        }

    }

    public static long factiter(long n) {
        long num = n;
        long total = 1;
        if (num != 0 | num != 1) {
            total = num;
        } else if (num == 1 | num == 0) {
            total = 1;
        }
        long num2;
        while (num > 1) {
            num2 = num - 1;
            total = total * num2;
            num = num - 1;
        }
        return total;
    }
}
