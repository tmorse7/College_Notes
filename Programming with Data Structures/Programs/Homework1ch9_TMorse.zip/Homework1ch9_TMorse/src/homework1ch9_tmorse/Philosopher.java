package homework1ch9_tmorse;

/**
 * @date Feb 5, 2017
 * @author Tristan Morse
 */
public class Philosopher implements Speaker{
    private String name;
    
    void Philosopher(){
    }
    
    @Override
    public void speak(){
        name = "Socrates";
        System.out.println(name + " says: \"An unexamined life is not worth living.\"");
    }
    
    @Override
    public void announce(String str){
        name = "Socrates";
        System.out.println(name +" announces: " + str);
    }
    
    public void pontificate(){
        name = "Socrates";
        System.out.println(name + " pontificates: \"To find yourself, think for yourself.\"");
    }
}
