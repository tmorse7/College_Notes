package homework1ch9_tmorse;

/**
 * @date Feb 5, 2017
 * @author Tristan Morse
 */
public class Cat implements Speaker{
    private String name;
    
    void Cat(){
    }
    
    @Override
    public void speak(){
        name = "Frank";
        System.out.println(name + " says: \"Meow\"");
    }
    
    public void hairball(){
        name = "Frank";
        System.out.println(name + " hacks: \"BLEH\"");
    }
    
    @Override
    public void announce(String str){
        name = "Frank";
        System.out.println(name +" announces: " + str);
    }
}
