package homework1ch9_tmorse;

/**
 * @date Feb 5, 2017
 * @author Tristan Morse
 */
public interface Speaker {
    public void speak();
    public void announce(String str);
}
