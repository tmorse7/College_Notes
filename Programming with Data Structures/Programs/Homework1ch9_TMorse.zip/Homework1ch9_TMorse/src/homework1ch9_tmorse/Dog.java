package homework1ch9_tmorse;

/**
 * @date Feb 5, 2017
 * @author Tristan Morse
 */
public class Dog implements Speaker{
    private String name;
    
    void Dog(){
    }
    
    @Override
    public void speak(){
        name = "Ralph";
       System.out.println(name + " says: \"Woof\"");
    }
    
    @Override
    public void announce(String str){
        name = "Ralph";
        System.out.println(name + " announces: " + str);
    }
}
