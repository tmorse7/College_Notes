package homework1ch9_tmorse;

/**
 * @date Feb 5, 2017
 * @author Tristan Morse
 */
public class SpeakerTest {

    public static void main(String[] args) {
        
        Speaker mySpeaker;
        
        mySpeaker = new Cat();
        mySpeaker.speak();
        mySpeaker.announce("Let's play a little game of cat and mouse.");
        ((Cat)mySpeaker).hairball();
        System.out.println("");
        
        mySpeaker = new Dog();
        mySpeaker.speak();
        mySpeaker.announce("\"I\'m a good boy!");
        System.out.println("");
        
        mySpeaker = new Philosopher();
        mySpeaker.speak();
        mySpeaker.announce("\"True knowledge exists in knowing that you know nothing.\"");
        ((Philosopher)mySpeaker).pontificate();
        System.out.println("");
    }
}
