package chapter8animals;

/**
 *
 * @author leejohnson
 */
public class Dog extends Animal {
    
    
     public Dog() {
        super();
          weight=99; 
    }
     
     
    @Override
    public String speak() {
        return "Woof!";
    }
    
}
