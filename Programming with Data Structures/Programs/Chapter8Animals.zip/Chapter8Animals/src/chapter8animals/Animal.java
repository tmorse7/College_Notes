package chapter8animals;

/**
 *
 * @author leejohnson
 */
public class Animal {

    protected float weight;
    protected String noise;

    public Animal() {
        weight = 1.0F;
        noise = "HU?";
        System.out.println("I'm a constructed Animal...");

    }

    public String speak() {
        return noise;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public float getWeight() {
        return weight;
    }

}
