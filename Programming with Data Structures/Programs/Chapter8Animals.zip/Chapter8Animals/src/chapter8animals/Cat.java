
package chapter8animals;

/**
 *
 * @author leejohnson
 */
public class Cat extends Animal {

    public Cat() {
        super();
          }

    @Override
    public String speak() {
        return "Meow! not " +  super.speak();
    }
    
    
}
