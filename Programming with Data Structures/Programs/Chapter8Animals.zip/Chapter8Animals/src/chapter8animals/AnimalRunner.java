package chapter8animals;

/**
 *
 * @author leejohnson
 */
public class AnimalRunner {
  
    public static void main(String[] args) {
        
        Animal myAnimal = new Animal(); 
        System.out.println("I am a generalized Animal and say " 
                + myAnimal.speak() );
        System.out.println("I weigh "+ myAnimal.getWeight() );
        System.out.println("   "); 
        
        Cat myCat = new Cat(); 
        myCat.setWeight(12.2F);
        System.out.println("I am a Cat and say "+ myCat.speak() );
        System.out.println("I weigh "+ myCat.getWeight() );
        System.out.println("   "); 
        
        Dog myDog = new Dog(); 
        System.out.println("I am a Dog and say "+ myDog.speak() );
        System.out.println("I weigh "+ myDog.getWeight() );
        System.out.println("   ");


//    Will this work?    
        //Animal myThing1 = new Cat();
        //System.out.println(myThing1.speak() );
        //System.out.println(myThing1.getWeight() );
        
//  Will this work?        
        //Cat myThing2 = new Animal();
        //System.out.println(myThing2.speak() );
    }
    
}
