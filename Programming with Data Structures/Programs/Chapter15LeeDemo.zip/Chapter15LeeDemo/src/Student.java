
/**
 *
 * @author leejohnson
 */
public class Student {

    private String firstName;
    private String lastName;
    private Boolean snarky;
    private Float gpa;

    public Student(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    Student() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Boolean getSnarky() {
        return snarky;
    }

    public void setSnarky(Boolean snarky) {
        this.snarky = snarky;
    }

    public Float getGpa() {
        return gpa;
    }

    public void setGpa(Float gpa) {
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return "Student{" + "firstName=" + firstName + ", lastName=" + lastName + ", snarky=" + snarky + ", gpa=" + gpa + '}';
    }

}
