/**
 * Demonstrate the creation and use of a LinkedList
 * and show Iterators and Comparators
 */
import java.util.Comparator;
import static java.util.Comparator.comparing;
import static java.util.Comparator.naturalOrder;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import static java.util.Comparator.comparing;

/**
 *
 * @author leejohnson
 */
public class LeeLinkedList {

    public static void main(String[] args) {

        List<Student> list = new LinkedList<>();
        //List<Student> list = new List<>(); // no joy

        Student s1 = new Student("Z", "Z");
        Student s2 = new Student("B", "B");
        Student s3 = new Student("A", "A");
        s3.setSnarky(Boolean.TRUE);

        list.add(s1);
        list.add(s2);
        list.add(s3);

        // Show off an Iterator for Chapter 16
        ListIterator<Student> i = list.listIterator();

        while (i.hasNext()) {
            Student tempstud = i.next();
            if (tempstud.getSnarky() == Boolean.TRUE) {
                System.out.println("Found a snarky student. Exterminate! " + tempstud);
                list.remove(tempstud);
            } // end of if
        } //end of while

        // Show off the new Java 8 Comparator for Chapter 18
        Comparator<Student> comparator = comparing(Student::getLastName, naturalOrder());

        list.sort(comparator);

        while (!list.isEmpty()) {
            Student temp = list.remove(0); // keep removing at zero ? 
            System.out.println("Removed remaining student: " + temp);
        } // end of while

    } // end of main

} //end of class 
