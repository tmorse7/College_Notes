import java.util.Random;

/**
 * Solution to Programming Project 18.3 (count comparisons)
 *
 * @author Java Foundations
 * Edited by Tristan Morse
 */
public class CompareSorts
{
   /**
    * Creates an array of random numbers and calls all sort methods on
    * those to see the results. Then does the same with a sorted list.
    */
   public static void main (String[] args)
   {
	  int arrayLength = 1000;
	  
      Integer randomSelection[] = new Integer[arrayLength];
      Integer randomInsertion[] = new Integer[arrayLength];
      Integer randomBubble[] = new Integer[arrayLength];
      Integer randomQuick[] = new Integer[arrayLength];
      Integer randomMerge[] = new Integer[arrayLength];
      Random randomGenerator = new Random();
      int randomNumber;
      
      for (int i = 0; i < arrayLength; i++) 
      {
    	  randomNumber = randomGenerator.nextInt();
    	  randomSelection[i] = randomNumber;
    	  randomInsertion[i] = randomNumber;
    	  randomBubble[i] = randomNumber;
    	  randomQuick[i] = randomNumber;
    	  randomMerge[i] = randomNumber;
      }

      System.out.println("*************************** Random List ****************************************");
      
      Sorting.selectionSort(randomSelection);
      Sorting.insertionSort(randomInsertion);
      Sorting.bubbleSort(randomBubble);
      Sorting.quickSort(randomQuick);
      Sorting.mergeSort(randomMerge);

	  
      Integer sortedSelection[] = new Integer[arrayLength];
      Integer sortedInsertion[] = new Integer[arrayLength];
      Integer sortedBubble[] = new Integer[arrayLength];
      Integer sortedQuick[] = new Integer[arrayLength];
      Integer sortedMerge[] = new Integer[arrayLength];
      
      for (int i = 0; i < arrayLength; i++) 
      {
    	  sortedSelection[i] = i;
    	  sortedInsertion[i] = i;
    	  sortedBubble[i] = i;
    	  sortedQuick[i] = i;
    	  sortedMerge[i] = i;
      }

      System.out.println("\n*************************** Sorted List ****************************************");
     
      Sorting.selectionSort(sortedSelection);
      Sorting.insertionSort(sortedInsertion);
      Sorting.bubbleSort(sortedBubble);
      Sorting.quickSort(sortedQuick);
      Sorting.mergeSort(sortedMerge);
     
   }
}
