package homework1ch8_tmorse;

/**
 * @date 2/2/17
 * @author Tristan Morse
 */
public class Doctor extends HospitalEmployee {
    
    String specialty;
    
    public Doctor(String empName, int empNumber, String special) {
        super(empName, empNumber);
        specialty = special;
        System.out.println("I'm a " + specialty + "!");
    }
    
    public void setSpecialty(String special){
        specialty = special;
    }
    
    public String getSpecialty(){
        return specialty;
    }
    
    public void diagnose(){
        System.out.println("It seems you have the common cold!");
    }
}
