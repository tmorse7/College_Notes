package homework1ch8_tmorse;

/**
 * @date 2/2/17
 * @author Tristan Morse
 */
public class Nurse extends HospitalEmployee {
    
    int numPatients;
    
    public Nurse(String empName, int empNumber, int numPat) {
        super(empName, empNumber);
        numPatients = numPat;
        System.out.println("I currently have " + numPatients + " patients that I'm looking after.");
    }
    
    public void setnumPat(int pat){
        numPatients = pat;
    }
    
    public int getnumPat(){
        return numPatients;
    }
    
    public void assist(){
        System.out.println("I'm here to assist the patient!");
    }
}