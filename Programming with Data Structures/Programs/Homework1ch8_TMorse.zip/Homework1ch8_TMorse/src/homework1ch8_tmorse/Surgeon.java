package homework1ch8_tmorse;

/**
 * @date 2/2/17
 * @author Tristan Morse
 */
public class Surgeon extends Doctor{
    
    boolean operating;
    
    public Surgeon(String empName, int empNumber, String special, boolean isOper) {
        super(empName, empNumber, special);
        operating = isOper;
    }
    
    public void setisOperating(boolean isOper){
        operating = isOper;
    }
    
    public boolean getisOperating(){
        return operating;
    }
    
    public void operate(){
        if(operating == true){
            System.out.println("I'll try not to touch the sides!");
        }
        
        if(operating == false){
            System.out.println("Not now! I'm eating!");
        }
    }
}
