package homework1ch8_tmorse;

/**
 * @date 2/2/17
 * @author Tristan Morse
 */
public class Janitor extends Administrator{
    
    boolean sweeping;
    
    public Janitor(String empName, int empNumber, String dept, boolean sw) {
        super(empName, empNumber, dept);
        sweeping = sw;
    }
    
    public void setisSweeping(boolean isS){
        sweeping = isS;
    }
    
    public boolean getisAnswering(){
        return sweeping;
    }
    
    public void sweep(){
        if(sweeping == true){
            System.out.println("This magic hat works wonders with brooms!");
        }
        
        if(sweeping == false){
            System.out.println("The floor is clean enough! No sweeping for now.");
        }
    }
}
