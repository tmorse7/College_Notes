package homework1ch8_tmorse;

/**
 * @date 2/2/17
 * @author Tristan Morse
 */
public class Administrator extends HospitalEmployee {
    
    String department;
    
    public Administrator(String empName, int empNumber, String dept) {
        super(empName, empNumber);
        department = dept;
        System.out.println("I'm a " + department);
    }
    
    public void setDepartment(String dept){
        department = dept;
    }
    
    public String getDepartment(){
        return department;
    }
    
    public void administrate(){
        System.out.println("I'll do my best!");
    }
}
