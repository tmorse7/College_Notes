package homework1ch8_tmorse;

/**
 * @date 2/2/17
 * @author Tristan Morse
 */
public class Hospital {

    public static void main(String[] args) {
        HospitalEmployee genericEmployee = new HospitalEmployee("Sapphire", 220557);
        genericEmployee.work();
        System.out.println(" ");
        
        Doctor genericDoc = new Doctor("Phil", 220556, "Dentist");
        genericDoc.work();
        genericDoc.diagnose();
        System.out.println(" ");
        
        Surgeon genericSurg = new Surgeon("Frank", 220555, "Brain Surgeon", true);
        genericSurg.work();
        genericSurg.diagnose();
        genericSurg.operate();
        System.out.println(" ");
        
        Nurse genericNurse = new Nurse("Violet", 220554, 35);
        genericNurse.work();
        genericNurse.assist();
        System.out.println(" ");
        
        Administrator genericAdmin = new Administrator("Tristan", 220558, "CEO");
        genericAdmin.work();
        genericAdmin.administrate();
        System.out.println(" ");
        
        Receptionist genericRecep = new Receptionist("Sylvia", 220553, "Receptionist", true);
        genericRecep.work();
        genericRecep.administrate();
        genericRecep.answer();
        System.out.println(" ");
        
        Janitor genericJan = new Janitor("Sophie", 220552, "2nd Floor Janitor", true); 
        genericJan.work();
        genericJan.administrate();
        genericJan.sweep();
        System.out.println(" ");
        
    }
    
}
