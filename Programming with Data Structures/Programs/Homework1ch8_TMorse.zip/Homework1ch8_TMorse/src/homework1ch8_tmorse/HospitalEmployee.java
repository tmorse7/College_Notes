package homework1ch8_tmorse;

/**
 * @date 2/2/17
 * @author Tristan Morse
 */
public class HospitalEmployee {
    String name;
    int number;
    
    public HospitalEmployee(String empName, int empNumber) {
        name = empName;
        number = empNumber;
        
        System.out.println("Hello! My name is: " + name);
        System.out.println("My number is: " + number);
    }
    
    public void setName(String empName) {
        name = empName;
    }
    
    public void setNumber(int empNumber) {
        number = empNumber;
    }
    
    public String getName() {
        return name;
    }
    
    public int getNumber(){
        return number;
    }
    
    public void work(){
        System.out.println("I'm working!");
    }
}
