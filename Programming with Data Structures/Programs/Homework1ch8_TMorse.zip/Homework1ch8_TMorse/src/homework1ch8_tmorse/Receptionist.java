package homework1ch8_tmorse;

/**
 * @date 2/2/17
 * @author Tristan Morse
 */
public class Receptionist extends Administrator{
    
    boolean answering;
    
    public Receptionist(String empName, int empNumber, String dept, boolean ans) {
        super(empName, empNumber, dept);
        answering = ans;
    }
    
    public void setisAnswering(boolean isAns){
        answering = isAns;
    }
    
    public boolean getisAnswering(){
        return answering;
    }
    
    public void answer(){
        if(answering == true){
            System.out.println("This is the doctor's office. What ails you?");
        }
        
        if(answering == false){
            System.out.println("We're sorry. We aren't available at the moment.");
        }
    }
}
