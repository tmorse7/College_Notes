package tmhomeworkch10pp1;

import java.util.Scanner;

/**
 * @date Feb 15, 2017
 * @author Tristan Morse (with some help from Ben Haynes)
 */
public class TMHomeworkch10PP1 {

    public static void main(String[] args) {

        String number;
        int totalNums = 0;

        Scanner scan = new Scanner(System.in);

        System.out.print("Enter list of numbers: ");

        for (int x = 0; x < 10; x++) {
            try 
            {
                number = scan.nextLine();
                int nums = Integer.parseInt(number);
                totalNums += nums;
            } 
            catch (NumberFormatException e) {
                System.out.println("Improper value set");
                x--;
            }
        }
        
        System.out.println("The average of these numbers is: " + totalNums/10);

    }
}
