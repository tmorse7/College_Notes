/**
 * Demonstrate the creation and use of a LinkedList
 * and show Iterators and Comparators
 */
import java.util.Comparator;
import static java.util.Comparator.comparing;
import static java.util.Comparator.naturalOrder;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import static java.util.Comparator.comparing;

/**
 * @Edited by Tristan Morse
 * @author leejohnson
 */
public class CPULinkedList {

    public static void main(String[] args) {

        List<CPU> list = new LinkedList<>();

        CPU c1 = new CPU("AMD Ryzen 7", "1700");
        CPU c2 = new CPU("Intel", "i5-7500");
        CPU c3 = new CPU("Intel", "i7-5960X");
        
        c1.setOverclockable(Boolean.TRUE);
        c2.setOverclockable(Boolean.FALSE);
        c3.setOverclockable(Boolean.TRUE);
        
        c1.setStckClckSpd(3.0);
        c2.setStckClckSpd(3.0);
        c3.setStckClckSpd(3.4);

        list.add(c1);
        list.add(c2);
        list.add(c3);

        // Show off an Iterator for Chapter 16
        ListIterator<CPU> i = list.listIterator();
        
        while (i.hasNext()) {
            CPU tempcpu = i.next();
            if (tempcpu.getOverclockable() == Boolean.FALSE) {
                System.out.println(tempcpu + "isn't overclockable! Removing from the list." + "\n");
                list.remove(tempcpu);
            }
        }

        // Show off the new Java 8 Comparator for Chapter 18
        Comparator<CPU> comparator = comparing(CPU::getCpuType, naturalOrder());

        list.sort(comparator);

        while (!list.isEmpty()) {
            CPU temp = list.remove(0); // keep removing at zero ? 
            System.out.println("Removed remaining CPU: " + temp);
        }

    }

}
