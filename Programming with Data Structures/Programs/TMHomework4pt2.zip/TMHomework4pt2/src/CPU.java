
/**
 * @Edited by Tristan Morse
 * @author leejohnson
 */
public class CPU {

    private String cpuBrand;
    private String cpuType;
    private Boolean overclockable;
    private Double stckClckSpd;

    public CPU(String cpuBrand, String cpuType) {
        this.cpuBrand = cpuBrand;
        this.cpuType = cpuType;
    }

    CPU() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String getCpuBrand() {
        return cpuBrand;
    }

    public void setCpuBrand(String cpuBrand) {
        this.cpuBrand = cpuBrand;
    }

    public String getCpuType() {
        return cpuType;
    }

    public void setCpuType(String cpuType) {
        this.cpuType = cpuType;
    }

    public Boolean getOverclockable() {
        return overclockable;
    }

    public void setOverclockable(Boolean overclockable) {
        this.overclockable = overclockable;
    }

    public Double getStckClckSpd() {
        return stckClckSpd;
    }

    public void setStckClckSpd(Double stckClckSpd) {
        this.stckClckSpd = stckClckSpd;
    }

    @Override
    public String toString() {
        return "Processor: " + "CPU Brand: " + cpuBrand + ", CPU Type: " + cpuType + ", Overclockable: " + overclockable + ", Stock Clock Speed: " + stckClckSpd + " GHz" + "\n";
    }

}
