
import java.util.Scanner;
import jsjf.LinkedStack;

/**
 * @date Mar 2, 2017
 * @author Tristan Morse
 * Original by Lee Johnson
 */
public class PP13Runner {

    public static void main(String[] args) {
        
        LinkedStack<String> myStack = new LinkedStack<>();
        
         try {
            Scanner in = new Scanner(System.in);
            System.out.println("Enter three words at the prompts.");
            for (int i = 1; i <= 3; i++) {
                System.out.print("Enter a word: ");
                myStack.push(in.nextLine());
            }
            // test for new peek()
            System.out.println("Peeking shows: " + myStack.peek());
            
            // test for new isEmpty()
            if (myStack.isEmpty()) {
                System.out.println("myStack is empty.");
            } else {
                System.out.println("myStack is not empty.");
            }
            
            // test for new toString()
            System.out.println();
            System.out.println("The Stack in a linked List is: ");
            // Breakpoint here to show stack.... 
            System.out.println(myStack + "\n");

            //test for new size() 
            System.out.println("The size of myStack is: " + myStack.size());
            System.out.println("In reverse order: ");
            while (!myStack.isEmpty()) {
                System.out.println(myStack.pop());
            }
        } catch (Exception IOException) {
            System.out.println("Input exception reported");
        }
    }

}
