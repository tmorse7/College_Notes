/*
* Started by Lee on Feb 10,2017 
*
* Use this program to start using files!!!!
*
* Be sure to read through it.
* Check out the try/catch/finally blocks from Chapter 10.
* Run it and it will read the file and write it to another file.
*   ( The files can be seen on the "Files" window. The tab for it is top left 
*       close to the "Projects" tab. ) 
* Do something to the data that was read from the file before writing it out.
* (I converted it to upper case)
 */

import java.io.*;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;

public class PlayWithFile {

    public static void main(String[] args) throws IOException {
        String inFileName = "infile.txt";
        String outFileName = "outfile.txt";
        PrintWriter outFile = null;

        try {
            String contents = new String(Files.readAllBytes(Paths.get(inFileName)));
            System.out.println("The contents of " + inFileName + " are : " + contents);

            // Insert magic here....
            outFile = new PrintWriter(outFileName);
            outFile.print(contents);
        } catch (NoSuchFileException e) {
            System.out.println("Error : " + e.toString());
        } finally {
            if (outFile != null) {
                outFile.close();
            }
            System.out.println("Output file has been created: " + outFileName);
        }

    }
}
